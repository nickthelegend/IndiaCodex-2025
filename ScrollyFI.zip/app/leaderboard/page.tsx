"use client"

import { EnhancedLeaderboard } from "@/components/enhanced-leaderboard"

export default function LeaderboardPage() {
  return <EnhancedLeaderboard />
}