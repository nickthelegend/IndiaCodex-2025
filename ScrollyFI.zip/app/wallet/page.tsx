"use client"

import { TokenWallet } from "@/components/token-wallet"

export default function WalletPage() {
  return <TokenWallet />
}