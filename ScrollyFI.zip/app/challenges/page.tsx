"use client"

import { DailyChallenges } from "@/components/daily-challenges"

export default function ChallengesPage() {
  return <DailyChallenges />
}